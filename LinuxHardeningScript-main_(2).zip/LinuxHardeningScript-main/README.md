# LinuxHardeningScript
Here is a script for CyberPatriot to hopefully automate the majority of manual tasks to save time.

## ReadMe Reader
This script will read the ReadMe and manage the users based on what the ReadMe says between 'Authorized Admin' and 'Authorized Users'. Though for this to work, you need to download the PDF version of the ReadMe and put it preferably on the Desktop.

## Running the script
After you download the MeowMeow file, put the MeowMoew file on your Desktop and open it in terminal. Give executable permissions to LinuxPatriot.sh & PDFreader.sh.
```
chmod +x LinuxPatriot
```
```
chmod +x PDFreader
```
Then just run the LinuxPatriot script as sudo.<br/>Make sure that you complete your forensics questions so you don't remove anything you could need for those questions.<br/>If you need points to access the forensics, just run the 'Update and Upgrade System' part of the script, then finish forensics before going any further.
```
sudo ./LinuxPatriot
```
### Notes
Note that the Password Configuration section changes ALL passwords including YOURS to: Secure123!Password <br/>This is still a work in progress sooo I'm still updating it ;)
