import pdfplumber

def extract_section(pdf_path, keywords, end_phrases):
    """
    Extracts sections from a PDF based on the provided keywords, stopping at
    specified end phrases or the next keyword.
    """
    extracted_text = {"Authorized Administrators": "", "Authorized Users": ""}

    with pdfplumber.open(pdf_path) as pdf:
        for page in pdf.pages:
            text = page.extract_text()
            if not text:
                continue  # Skip empty pages

            # Convert to lowercase for case-insensitive matching
            lower_text = text.lower()

            # Flags to track which section we are currently reading
            in_admin_section = False
            in_user_section = False

            for line in text.splitlines():
                lower_line = line.lower()
                
                # Check if we're entering a new section
                if "authorized administrators" in lower_line:
                    in_admin_section = True
                    in_user_section = False
                    continue
                elif "authorized users" in lower_line:
                    in_user_section = True
                    in_admin_section = False
                    continue
                elif any(end.lower() in lower_line for end in end_phrases):
                    # Stop reading further if we hit an end phrase
                    break
                
                # Add lines to the appropriate section based on the flag
                if in_admin_section:
                    extracted_text["Authorized Administrators"] += line + "\n"
                elif in_user_section:
                    extracted_text["Authorized Users"] += line + "\n"

    # Strip any trailing newlines and return the result
    return {key: value.strip() for key, value in extracted_text.items()}

if __name__ == "__main__":
    pdf_path = input("Enter the path to your PDF file: ")  # User input for PDF path
    end_phrases = ["COMPETITION GUIDELINES"]

    extracted_sections = extract_section(pdf_path, ["Authorized Administrators", "Authorized Users"], end_phrases)
    for section, content in extracted_sections.items():
        print(f"{section}\n{content}\n")