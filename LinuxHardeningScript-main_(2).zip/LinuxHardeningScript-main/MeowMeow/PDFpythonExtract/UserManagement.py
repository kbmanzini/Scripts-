"""
THIS SCRIPT REMOVES SOME OF THE NEEDED SYSTEM USERS
DON'T USE THIS ONE!!!
"""


import pdfplumber
import subprocess

def extract_section(pdf_path, keywords, end_phrases):
    extracted_text = {"Authorized Administrators": "", "Authorized Users": ""}
    with pdfplumber.open(pdf_path) as pdf:
        for page in pdf.pages:
            text = page.extract_text()
            if not text:
                continue

            lower_text = text.lower()
            in_admin_section = False
            in_user_section = False

            for line in text.splitlines():
                lower_line = line.lower()
                if "authorized administrators" in lower_line:
                    in_admin_section = True
                    in_user_section = False
                    continue
                elif "authorized users" in lower_line:
                    in_user_section = True
                    in_admin_section = False
                    continue
                elif any(end.lower() in lower_line for end in end_phrases):
                    break

                if in_admin_section:
                    extracted_text["Authorized Administrators"] += line + "\n"
                elif in_user_section:
                    extracted_text["Authorized Users"] += line + "\n"

    return {key: value.strip().splitlines() for key, value in extracted_text.items()}

def get_system_users():
    # Get all users and their groups from the system
    users = {}
    try:
        output = subprocess.check_output("getent passwd", shell=True, text=True)
        for line in output.splitlines():
            user = line.split(":")[0]
            # Check if the user is in the 'sudo' group (admin privileges)
            groups = subprocess.check_output(f"groups {user}", shell=True, text=True)
            users[user] = "admin" if "sudo" in groups else "user"
    except subprocess.CalledProcessError as e:
        print(f"Error retrieving users: {e}")
    return users

def enforce_compliance(system_users, authorized_admins, authorized_users):
    # Remove users not in the PDF
    all_authorized = set(authorized_admins + authorized_users)
    for user in system_users:
        if user not in all_authorized:
            print(f"Removing unauthorized user: {user}")
            subprocess.run(["sudo", "userdel", "-r", user])

    # Ensure correct privileges for authorized users
    for user in authorized_admins:
        if user not in system_users:
            print(f"Adding missing admin user: {user}")
            subprocess.run(["sudo", "useradd", "-m", "-G", "sudo", user])
        elif system_users[user] != "admin":
            print(f"Adding admin privileges to: {user}")
            subprocess.run(["sudo", "usermod", "-aG", "sudo", user])

    for user in authorized_users:
        if user not in system_users:
            print(f"Adding missing regular user: {user}")
            subprocess.run(["sudo", "useradd", "-m", user])
        elif system_users[user] == "admin":
            print(f"Removing admin privileges from: {user}")
            subprocess.run(["sudo", "deluser", user, "sudo"])

if __name__ == "__main__":
    pdf_path = input("Enter the path to your PDF file: ")
    end_phrases = ["COMPETITION GUIDELINES"]

    extracted_sections = extract_section(pdf_path, ["Authorized Administrators", "Authorized Users"], end_phrases)
    authorized_admins = extracted_sections["Authorized Administrators"]
    authorized_users = extracted_sections["Authorized Users"]

    system_users = get_system_users()
    enforce_compliance(system_users, authorized_admins, authorized_users)