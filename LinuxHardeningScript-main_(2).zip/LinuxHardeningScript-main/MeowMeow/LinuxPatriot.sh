#!/bin/bash
# Run this script as root

# Note that the Password Configuration section changes ALL passwords including YOURS to: Secure123!Password

# Check if the script is run as root
if [ "$EUID" -ne 0 ]; then
    echo "This script must be run as root. Please use sudo or run as root."
    exit 1
fi

# The rest of your script goes here
read -p "Running as root. Proceeding with script... (Hit Enter) ;)"

#1
# Update and Upgrade
update_system() {
    echo "Updating and upgrading system..."
    apt-get update && apt-get dist-upgrade -y
    apt autoremove -y
    echo "System Update Complete."
    read -p "Hit Enter to continue..."
}

#2
# Configuring the firewall
configure_firewall() {
    echo "Configuring UFW firewall..."

    # Check if UFW is already installed
    if ! dpkg -l | grep -q ufw; then
        echo "UFW not found, installing..."
        apt-get install ufw -y
    else
        echo "UFW is already installed."
    fi

    # Enable UFW if it's not already active
    if ! ufw status | grep -q "active"; then
        echo "UFW is inactive, enabling it now."
        ufw enable
    fi

    # Set default policies
    ufw default deny incoming
    ufw default allow outgoing
    # Allow essential services
    ufw allow ssh
    ufw allow http
    ufw allow https
    # Optional: Allow additional ports for other services, e.g., FTP, DNS
    # ufw allow 21   # FTP
    # ufw allow 53   # DNS
    # Enable logging for firewall activity
    ufw logging on
    # Optional: Limit SSH login attempts to prevent brute force attacks
    ufw limit ssh
    # Reload the firewall to apply all changes
    ufw reload
    echo "Firewall Enabled and Configured."
    read -p "Hit Enter to continue..."
}

#3
# Setting Password Policies and PAM Configuration with User Review Option
set_password_policies() {
    echo "Starting enhanced password policy configuration..."

    # Ensure libpam-cracklib is installed
    if ! dpkg -l | grep -q libpam-cracklib; then
        echo "Installing libpam-cracklib for password policy enforcement..."
        sudo apt-get install libpam-cracklib -y
    else
        echo "libpam-cracklib is already installed."
    fi

    # Back up original configuration files before modification
    echo "Backing up configuration files..."
    cp /etc/login.defs /etc/login.defs.bak
    cp /etc/pam.d/common-password /etc/pam.d/common-password.bak
    cp /etc/pam.d/common-auth /etc/pam.d/common-auth.bak

    # Update /etc/login.defs for system-wide password policies
    echo "Updating /etc/login.defs with password policy settings..."
    sed -i 's/^PASS_MAX_DAYS.*/PASS_MAX_DAYS\t90/' /etc/login.defs
    sed -i 's/^PASS_MIN_DAYS.*/PASS_MIN_DAYS\t7/' /etc/login.defs
    sed -i 's/^PASS_WARN_AGE.*/PASS_WARN_AGE\t14/' /etc/login.defs

    # Prompt user to review /etc/login.defs
    read -p "Would you like to review /etc/login.defs? (y/n): " review_login_defs
    if [[ "$review_login_defs" == "y" ]]; then
        gedit /etc/login.defs
    fi

    # Edit PAM common-password for enhanced password policies
    echo "Configuring PAM for password complexity requirements..."

    # Add pam_cracklib if not present
    if ! grep -q "pam_cracklib.so" /etc/pam.d/common-password; then
        sed -i '/^password\s\+requisite\s\+pam_deny.so/a\password requisite pam_cracklib.so minlen=12 ucredit=-1 lcredit=-1 dcredit=-1 ocredit=-1' /etc/pam.d/common-password
    fi

    # Ensure password complexity and history enforcement
    sed -i '/^password\s\+required\s\+pam_unix.so/s/$/ remember=5/' /etc/pam.d/common-password

    # Prompt user to review /etc/pam.d/common-password
    read -p "Would you like to review /etc/pam.d/common-password? (y/n): " review_common_password
    if [[ "$review_common_password" == "y" ]]; then
        gedit /etc/pam.d/common-password
    fi

    # Configure PAM common-auth for account lockout after failed attempts
    echo "Setting lockout policies for failed login attempts..."
    if ! grep -q "pam_tally2.so" /etc/pam.d/common-auth; then
        sed -i '/^auth\s\+required\s\+pam_deny.so/a\auth required pam_tally2.so deny=5 unlock_time=900' /etc/pam.d/common-auth
    fi

    # Prompt user to review /etc/pam.d/common-auth
    read -p "Would you like to review /etc/pam.d/common-auth? (y/n): " review_common_auth
    if [[ "$review_common_auth" == "y" ]]; then
        gedit /etc/pam.d/common-auth
    fi

    # Set password for all users who have a UID >= 1000 (excluding system users)
    echo "Changing passwords for all users with UID >= 1000..."
    new_password="Secure123!Password"
    users=$(awk -F: '{if ($3 >= 1000) print $1}' /etc/passwd)

    for user in $users; do
        echo "Changing password for user: $user"
        echo "$user:$new_password" | chpasswd
    done

    echo "Password policies and configurations have been set successfully."
    echo "Backups of original configuration files are located in /etc/."
    echo "All passwords set to: Secure123!Password"
    read -p "Hit Enter to continue..."
}

#4
# Securing SSH configuration
secure_ssh() {
    echo "Securing SSH configuration..."
    sed -i 's/^PasswordAuthentication.*/PasswordAuthentication no/' /etc/ssh/sshd_config
    sed -i 's/^ChallengeResponseAuthentication.*/ChallengeResponseAuthentication no/' /etc/ssh/sshd_config
    sed -i 's/^PermitRootLogin.*/PermitRootLogin no/' /etc/ssh/sshd_config
    systemctl restart sshd
    echo "Secuing SSH Configuration Complete."
    cat /etc/ssh/sshd_config
    read -p "Hit Enter to continue..."
}

#5
# Malware/Backdoor scanning with rkhunter
run_malware_scan() {
    echo "Scanning for potential backdoors and malware..."

    # Use rkhunter and chkrootkit for basic scanning
    apt-get install -y rkhunter chkrootkit
    rkhunter --update
    rkhunter --check --skip-keypress
    chkrootkit
    echo ""
    echo "Backdoor and keylogger scan complete. Review the results above."
    read -p "Hit Enter to continue..."
}

#6
# Disables the guest account & Locking nobody & Locking root account
disable_guest_account() {
    # If Box is Lightdm for disabling guest account
    disable_lightdm_guest() {
    echo "Disabling guest account in LightDM..."
    if [ -f /etc/lightdm/lightdm.conf ]; then
        # If lightdm.conf exists, append setting
        echo "[SeatDefaults]" >> /etc/lightdm/lightdm.conf
        echo "allow-guest=false" >> /etc/lightdm/lightdm.conf
    else
        # Create the file and add the necessary lines
        echo "[SeatDefaults]" > /etc/lightdm/lightdm.conf
        echo "allow-guest=false" >> /etc/lightdm/lightdm.conf
    fi
    echo "Guest account disabled for LightDM."
    }

    # If Box is gdm for disabling guest account
    disable_gdm_guest() {
    echo "Disabling guest account in GDM..."
    if [ -f /etc/gdm3/custom.conf ]; then
        # If custom.conf exists, append setting
        sed -i '/^\[daemon\]/a AllowGuest=false' /etc/gdm3/custom.conf
    else
        # Create the file and add the necessary lines
        echo "[daemon]" > /etc/gdm3/custom.conf
        echo "AllowGuest=false" >> /etc/gdm3/custom.conf
    fi
    echo "Guest account disabled for GDM."
    }

    # If none worked
    # Check if LightDM or GDM is installed, then disable guest login accordingly
    if command -v lightdm >/dev/null 2>&1; then
        disable_lightdm_guest
    elif command -v gdm3 >/dev/null 2>&1; then
        disable_gdm_guest
    else
        echo "Neither LightDM nor GDM is installed. No guest account settings were modified."
    fi
    echo "Locking nobody account"
    usermod -L nobody
    echo "Locking root account"
    usermod -L root
    echo ""
    read -p "Hit Enter to continue..."

}

#7
# Searching for suspicious files
search_suspicious_files() {
    echo "Searching for suspicious files..."

    # Define an array of suspicious file extensions
    suspicious_exts=("mp3" "mp4" "exe" "avi" "wav" "mov" "mkv" "flac" "mpg" "mpeg" "wmv"
                     "zip" "tar" "gz" "rar" "7z" "sh" "bat" "dll" "msi" "iso" "img" "apk" "jar")

    # Create/clear the log file
    log_file="suspicious_files.log"
    > "$log_file"

    # Loop through each file type and search specifically for that type
    for ext in "${suspicious_exts[@]}"; do
        echo "\n=== .${ext} Files ===" >> "$log_file"
        find / -type f -name "*.${ext}" >> "$log_file" 2>/dev/null
    done
    echo ""
    echo "Results organized by file type and saved to $log_file."
    read -p "Hit Enter to continue..."
}

#8
# Setting up logging
setup_logging() {
    echo "Setting up centralized logging..."
    apt-get install -y rsyslog
    systemctl enable rsyslog
    systemctl start rsyslog
    echo ""
    echo "Logging Setup Complete."
    echo ""
    echo "By default, rsyslog stores system logs in the following locations:
	•	General system logs: /var/log/syslog
	•	Authentication logs: /var/log/auth.log
	•	Kernel logs: /var/log/kern.log
	•	Boot logs: /var/log/boot.log
	•	Application logs (depending on configuration): Usually stored under /var/log/ in application-specific subdirectories or files."
    echo ""
    read -p "Hit Enter to continue..."
}

#9
# Function to check Secure Boot status and provide guidance if disabled
check_secure_boot() {
    echo "Checking Secure Boot status..."
    echo ""
    mokutil --sb-state
    echo ""
    read -p "Press Enter to continue..."
}

#10
# Enabling 2FA
enable_2fa() {
    echo "Installing Google Authenticator for 2FA..."
    apt-get install -y libpam-google-authenticator

    # Ensure PAM module is added to SSH configuration
    echo "auth required pam_google_authenticator.so" >> /etc/pam.d/sshd

    # Enforce ChallengeResponseAuthentication in sshd_config
    SSHD_CONFIG="/etc/ssh/sshd_config"
    if grep -q "^ChallengeResponseAuthentication" "$SSHD_CONFIG"; then
        sudo sed -i 's/^ChallengeResponseAuthentication.*/ChallengeResponseAuthentication yes/' "$SSHD_CONFIG"
    else
        echo "ChallengeResponseAuthentication yes" | sudo tee -a "$SSHD_CONFIG" > /dev/null
    fi

    # Restart SSH service to apply changes
    systemctl restart ssh
    echo ""
    echo "2FA Enabled using Google Authenticator."
    echo ""
    echo "User Setup: Each user needs to run google-authenticator and follow the on-screen instructions to link their account to the Google Authenticator app on their phone."
    echo ""
    read -p "Hit Enter to continue..."
}

#11
# File integrity monitoring with AIDE
enable_file_integrity_monitoring() {
    echo "Installing and initializing AIDE for file integrity monitoring..."
    apt-get install -y aide
    aideinit
    echo ""
    echo "AIDE Installed and Ran for File Integrity monitoring."
    read -p "Hit Enter to continue..."
}

#12
# Securing Apache web server
secure_apache() {
    echo "Securing Apache web server..."
    a2enmod ssl
    systemctl restart apache2
    echo ""
    echo "Securing Apache Web Server Complete."
    read -p "Hit Enter to continue..."
}

#13
# Enabling AppArmor
# Enhances system security by confining programs to a limited set of resources and permissions. 
enable_apparmor() {
    echo "Enabling AppArmor and applying security profiles..."
    apt-get install -y apparmor apparmor-utils
    aa-enforce /etc/apparmor.d/*
    echo "Enabled AppArmor."
    read -p "Hit Enter to continue..."
}

#14
# Intrusion detection with Fail2Ban
enable_fail2ban() {
    echo "Installing Fail2Ban..."
    apt-get install -y fail2ban
    systemctl enable fail2ban
    systemctl start fail2ban
    echo ""
    echo "Fail2Ban Installed and Setup for Intrusion Detection."
    read -p "Hit Enter to continue..."
}

#15
# Running Lynis audit
# Lynis audits your system’s security by checking for potential weaknesses, configurations, and best practices.
run_lynis_audit() {
    echo "Checking if Lynis is installed..."

    # Check if Lynis is already installed
    if ! dpkg -l | grep -q lynis; then
        echo "Lynis not found, installing..."
        apt-get install -y lynis
    else
        echo "Lynis is already installed."
    fi

    # Ask the user if they want to save the audit report
    read -p "Would you like to save the Lynis audit report? (y/n): " save_report

    # Run the audit
    echo "Running Lynis Security Audit..."
    audit_command="lynis audit system"
    if [ "$save_report" == "y" ] || [ "$save_report" == "Y" ]; then
        # Save the audit report to a file
        report_file="/var/log/lynis/$(date +'%Y%m%d')_lynis_report.txt"
        mkdir -p /var/log/lynis
        $audit_command > $report_file
        echo "Lynis audit completed. Report saved to $report_file"
    else
        # Run the audit without saving the report
        $audit_command
        echo "Lynis audit completed."
    fi

    # Search the report for critical warnings or failures
    read -p "Would you like to check for critical warnings/failures in the audit? (y/n): " check_issues
    if [ "$check_issues" == "y" ] || [ "$check_issues" == "Y" ]; then
        if [ "$save_report" == "y" ] || [ "$save_report" == "Y" ]; then
            echo "Checking the audit report for critical issues..."
            grep -iE 'warning|failure|failed|critical' $report_file
        else
            echo "Please save the report first to check for critical issues."
        fi
    fi
    read -p "Hit Enter to continue..."
}

#16
# User Management
manage_users() {
    ./PDFreader.sh
    echo ""
    echo "--Here are all of the users now--"
    mawk -F: '$3 > 999 && $3 < 65534 {print $1}' /etc/passwd
    echo ""
    echo "--Here are the admin users now--"
    mawk -F: '$1 == "sudo"' /etc/group
    echo ""
    echo "Users have been managed ;)"
    read -p "Hit Enter to continue..."
}

#17
# Setting up Audit
audit_setup() {
    echo "Checking if auditd is installed..."

    # Check if auditd is already installed
    if ! dpkg -l | grep -q auditd; then
        echo "auditd not found, installing..."
        apt-get install auditd -y
    else
        echo "auditd is already installed."
    fi

    echo "Enabling Audits"
    auditctl -e 1

    # Configure basic audit rules
    echo "Setting up basic audit rules..."
    cat <<EOL > /etc/audit/rules.d/audit.rules
# Monitor all administrative actions
-w /etc/sudoers -p wa -k sudoers_changes
-w /etc/group -p wa -k group_changes
-w /etc/passwd -p wa -k passwd_changes

# Monitor system configuration files
-w /etc/ssh/sshd_config -p wa -k ssh_config_changes
-w /etc/hostname -p wa -k hostname_changes

# Monitor login attempts
-w /var/log/auth.log -p wa -k auth_logs

# Monitor any new executable binaries in /usr/local/bin
-w /usr/local/bin -p wa -k bin_changes
EOL

    echo "Audit rules added. Reloading auditd..."
    service auditd restart

    # Ask the user if they want to review the audit policy
    read -p "Would you like to review the audit policy configured? (y/n): " review_choice

    if [ "$review_choice" == "y" ] || [ "$review_choice" == "Y" ]; then
        gedit /etc/audit/auditd.conf
    else
        echo "Audit Policy Complete"
    fi
    read -p "Hit Enter to continue..."
}

#18
# Adding Group and Users to Group
group_add() {
    # Prompt for the group name
    read -p "Enter the name of the group to create: " group_name

    # Check if the group already exists
    if getent group "$group_name" > /dev/null 2>&1; then
        echo "Group '$group_name' already exists."
    else
        # Create the group
        sudo groupadd "$group_name"
        echo "Group '$group_name' created successfully."
    fi

    # Prompt for users to add to the group
    read -p "Enter the usernames to add to the group (separate by spaces): " -a users

    # Iterate over the provided usernames
    for user in "${users[@]}"; do
        # Check if the user exists on the system
        if id "$user" &> /dev/null; then
            # Add the user to the group
            sudo usermod -aG "$group_name" "$user"
            echo "User '$user' added to the group '$group_name'."
        else
            echo "User '$user' does not exist on the system. Skipping..."
        fi
    done
    echo ""
    # Print the group name and its members
    group_members=$(getent group "$group_name" | awk -F: '{print $4}')
    echo "--Group Made & Users Added--"
    echo "$group_name: $group_members"
    echo ""
    read -p "Hit Enter to continue..."
}

#19
# Disable Unsafe/Unneeded Services
service_management() {
    echo "Disabling unnecessary services as per CIS Benchmark recommendations..."

    # Disable Avahi Daemon (Multicast DNS service)
    systemctl disable avahi-daemon.service --now

    # Disable CUPS (Common UNIX Printing System) if not required
    systemctl disable cups.service --now

    # Disable NFS server (Network File System), only enable if needed for file sharing
    systemctl disable nfs-kernel-server.service --now

    # Disable RPCBind service (Remote Procedure Call) - often unnecessary and a potential attack vector
    systemctl disable rpcbind.service --now

    # Disable vsftpd (FTP server) if not needed - FTP is an insecure protocol, recommend using SFTP
    systemctl disable vsftpd.service --now

    # Disable telnet service (if present, as it’s an insecure protocol)
    systemctl disable telnet.socket --now

    # Disable rsh service (Remote Shell), if present
    systemctl disable rsh.socket --now

    # Disable Bluetooth service if not used, especially on servers or systems where Bluetooth is unnecessary
    systemctl disable bluetooth.service --now

    # Disable the SNMP service (Simple Network Management Protocol), unless required for network management
    systemctl disable snmpd.service --now

    # Disable the Postfix service if email functionality is not required
    systemctl disable postfix.service --now

    # Remote Desktop Services (VNC, xrdp) disable
    systemctl disable xrdp.service --now
    systemctl disable vncserver@.service --now

    echo ""
    echo "Unnecessary services have been disabled."
    read -p "Hit Enter to continue..."
}

#20 
# USB Security
usb_disable() {
    echo "System Won't Recognize USBs"
    # This prevents the system from recognizing and mounting USB storage devices
    echo "install usb-storage /bin/true" | sudo tee /etc/modprobe.d/disable-usb-storage.conf
    echo "Blocking USB Storage"
    # Block USB storage devices from being recognized by creating a udev rule.
    echo 'ACTION=="add", SUBSYSTEM=="usb", ATTR{product}=="USB_DISK", ATTR{authorized}="0"' | sudo tee /etc/udev/rules.d/00-usb-block.rules
    echo "Logging and Monitoring USB"
    # Log USB insertions to track any attempts to insert unauthorized devices
    echo 'ACTION=="add", SUBSYSTEM=="usb", RUN+="/usr/bin/logger USB device inserted: $env{DEVNAME}"' | sudo tee /etc/udev/rules.d/99-usb-log.rules
    echo ""
    echo "System Doesn't Recognize & Mount USB storage devices."
    echo "Created udev rule to Block USB storage devices from being recognized."
    echo "Logging of USB insertions enabled."
    read -p "Hit Enter to continue..."
}

#21
# Check File Permissions and Change for Sensitive Files
file_permissions() {
    # Function to check and fix permissions for sensitive files
    check_and_fix_permissions() {
        file=$1
        expected_perm=$2

        # Get the current permissions in numeric format
        current_perm=$(stat -c "%a" "$file")

        # Check if the current permissions match the expected ones
        if [ "$current_perm" -ne "$expected_perm" ]; then
            echo "Incorrect permissions for $file (current: $current_perm, expected: $expected_perm). Fixing..."
            chmod "$expected_perm" "$file"
            echo "Permissions for $file have been corrected to $expected_perm."
        else
            echo "Permissions for $file are already set correctly ($current_perm)."
        fi
    }

    # Check and fix permissions for /etc/shadow and /etc/passwd
    check_and_fix_permissions "/etc/shadow" 640
    check_and_fix_permissions "/etc/passwd" 644
    check_and_fix_permissions "/etc/group" 644
    check_and_fix_permissions "/etc/gshadow" 640
    check_and_fix_permissions "/etc/sudoers" 440
    check_and_fix_permissions "/etc/ssh/sshd_config" 600
    check_and_fix_permissions "/boot/grub/grub.cfg" 600
    check_and_fix_permissions "/etc/sudoers.d" 750

    echo "Permission check and adjustments complete."
    read -p "Hit Enter to continue..."
}

#22
# Check open ports
check_ports() {
    # Run ss to list open ports
    echo "Checking open ports..."
    ss -tuln

    # Ask if there are unwanted ports running
    read -p "Are there any unwanted ports running? (y/n): " answer

    if [[ "$answer" == "y" ]]; then
        # Ask for the unwanted port number
        read -p "Enter the port number to close: " port

        # Find the PID of the service running on the given port
        pid=$(sudo lsof -t -i :$port)

        # Check if a PID was found
        if [ -z "$pid" ]; then
            echo "No process is running on port $port."
        else
            # Find the service name (can be the command or service name)
            service=$(ps -p $pid -o comm=)

            # Show the service and PID
            echo "The service running on port $port is $service with PID $pid."

            # Confirm before killing the service
            read -p "Do you want to kill this service? (y/n): " kill_answer
            if [[ "$kill_answer" == "y" ]]; then
                # Kill the service
                sudo kill $pid
                echo "Service $service with PID $pid has been killed."
            else
                echo "Service was not killed."
            fi
        fi
    else
        echo "No unwanted ports were found."
    fi
}

#99
# Reboot System
reboot_system() {
    reboot now
}

# Main menu loop
while true; do
    echo ""
    echo "--Script Kiddies CyberPatriot Linux Script--"
    echo " /\_/\  "
    echo "( o.o ) "
    echo " > ^ <  "
    echo "--Select an Option--"
    echo "1: Update and Upgrade System         12: Secure Apache Web Server"
    echo "2: Configure UFW Firewall            13: Enabling AppArmor"
    echo "3: Password Policy                   14: Fail2Ban Intrusion Detection"
    echo "4: Securing SSH                      15: Run Lynis Security Audit"
    echo "5: Run Malware Scan with rkhunter    16: Manage Users"
    echo "6: Disable Guest Account             17: Audit Setup"
    echo "7: Search for Sus Files              18: Adding Groups"
    echo "8: Setup Logging                     19: Service Management"
    echo "9: Check Boot Status                 20: USB Security"
    echo "10: 2FA (Google Authenticator)       21: Sensitive File Security"
    echo "11: AIDE File Integrity Monitoring   22: Check Ports"
    echo ""
    echo "0: Exit"
    echo "99: Reboot"
    echo ""
    
    # Get user input
    read -p "Enter your choice: " choice

    case $choice in
        1) update_system ;;
        2) configure_firewall ;;
        3) set_password_policies ;;
        4) secure_ssh ;;
        5) run_malware_scan ;;
        6) disable_guest_account ;;
        7) search_suspicious_files ;;
        8) setup_logging ;;
        9) check_secure_boot ;;
        10) enable_2fa ;;
        11) enable_file_integrity_monitoring ;;
        12) secure_apache ;;
        13) enable_apparmor ;;
        14) enable_fail2ban ;;
        15) run_lynis_audit ;;
        16) manage_users ;;
        17) audit_setup ;;
        18) group_add ;;
        19) service_management ;;
        20) usb_disable ;;
        21) file_permissions ;;
        22) check_ports ;;
        99) reboot_system ;;
        0) echo "Exiting..."; break ;;
        *) read -p "Invalid option, hit enter and try again..." ;;
    esac
done