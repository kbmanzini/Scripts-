#!/bin/bash

# Check if Python 3 is installed
if ! command -v python3 &> /dev/null; then
    echo "Python 3 is not installed. Installing Python 3..."
    sudo apt update
    sudo apt install -y python3
else
    echo "Python 3 is already installed."
fi

# Check if pip is installed
if ! command -v pip3 &> /dev/null; then
    echo "pip3 is not installed. Installing pip3..."
    sudo apt update
    sudo apt install -y python3-pip
else
    echo "pip3 is already installed."
fi

# Check if pdfplumber is installed
if ! python3 -c "import pdfplumber" &> /dev/null; then
    echo "pdfplumber is not installed. Installing pdfplumber..."
    pip3 install pdfplumber
else
    echo "pdfplumber is already installed."
fi

# Notify user that all requirements are installed
echo "All requirements are installed for your Python script."

# Run the Python script
python3 /home/ubuntu/Desktop/LinuxHardeningScript/MeowMeow/PDFpythonExtract/UserManagement2.0.py